package com.nirmaydas.serverside;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class Catalog {
    private Map<Integer, Item> items; 
    private MongoCollection<Document> booksCollection;

    public Catalog() {
        this.items = new HashMap<>();
        MongoClient mongoClient = MongoClients.create("mongodb://nirmaycosmosdb12345:ZdHFvysXfRetzpaKUESRX9uXuKCmWrdoaMoD0FF4a26VlCouvY9mDANW0CH6ejeat5vcUU759vGSACDbab8FXg==@nirmaycosmosdb12345.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false");
        MongoDatabase database = mongoClient.getDatabase("library");
        this.booksCollection = database.getCollection("books");
        loadCatalog();
    }

    private void loadCatalog() {
        items.clear();
        for (Document doc : booksCollection.find()) {
            int id = doc.getInteger("id");
            String type = doc.getString("type");
            String title = doc.getString("title");
            String author = doc.getString("author");
            boolean isAvailable = doc.getBoolean("isAvailable");
            String borrowedBy = doc.getString("borrowedBy");
            String imageUrl = doc.getString("imageUrl");
            List<String> tags = doc.getList("tags", String.class, new ArrayList<>());
            Item item = new Item(type, title, author, id, isAvailable, borrowedBy, imageUrl);
            item.setTags(tags);
            items.put(id, item);
        }
        System.out.println("Cattalog size: " + items.size() + " from mongo.");
    }

    // update catalog.txt file with whatever client does
    public void saveCatalog() {
        booksCollection.drop();
        for (Item item : items.values()) {
            Document doc = new Document("id", item.getId())
                .append("type", item.getType())
                .append("title", item.getTitle())
                .append("author", item.getAuthor())
                .append("isAvailable", item.isAvailable())
                .append("borrowedBy", item.getBorrowedBy())
                .append("imageUrl", item.getImageUrl())
                .append("tags", item.getTags());
            booksCollection.insertOne(doc);
        }
        System.out.println("Catalog saved to MongoDB.");
    }

    // get all books
    public Map<Integer, Item> getItems() {
        return items;
    }

    // client borrows book
    public synchronized String borrowItem(int itemId, String memberId) {
        Item item = items.get(itemId);
        if (item == null) {
            return "Error: Item ID " + itemId + " does not exist";
        }
        if (!item.isAvailable()) {
            return "Error: Item not available";
        }
        item.setAvailable(false);
        item.setBorrowedBy(memberId);
        saveCatalog(); 
        return ("Borrowed " + item.getTitle());
    }

    // client returns book
    public synchronized String returnItem(int itemId, String memberId) {
        Item item = items.get(itemId);
        if (item == null) {
            return "Error: Item ID " + itemId + " does not exist";
        }
        if (item.isAvailable() || !memberId.equals(item.getBorrowedBy())) {
            return "Error: Cannot return this item";
        }
        item.setAvailable(true);
        item.setBorrowedBy(null);
        saveCatalog();
        return "Returned " + item.getTitle();
    }
}