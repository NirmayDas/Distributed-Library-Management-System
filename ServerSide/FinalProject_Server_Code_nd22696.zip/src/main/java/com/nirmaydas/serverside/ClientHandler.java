package com.nirmaydas.serverside;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.google.gson.Gson;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document; 

public class ClientHandler implements Runnable {
    private final Socket clientSocket;
    private final Catalog catalog;
    private final AccountManager accountManager;
    private String memberId;
    private final MongoCollection<Document> reviewsCollection;

    public ClientHandler(Socket clientSocket, Catalog catalog) {
        this.clientSocket = clientSocket;
        this.catalog = catalog;
        this.accountManager = new AccountManager();
        MongoClient mongoClient = MongoClients.create("mongodb://nirmaycosmosdb12345:ZdHFvysXfRetzpaKUESRX9uXuKCmWrdoaMoD0FF4a26VlCouvY9mDANW0CH6ejeat5vcUU759vGSACDbab8FXg==@nirmaycosmosdb12345.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false");
        MongoDatabase database = mongoClient.getDatabase("library");
        this.reviewsCollection = database.getCollection("reviews");
        
    }

    @Override
    public void run() {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String command;
            Gson gson = new Gson();

            //Command processing:
            while ((command = in.readLine()) != null) {
                Command cmd = gson.fromJson(command, Command.class);
                String action = cmd.getCommand();

                //LOGIN
                if (action.equals("LOGIN")) {
                    String memberId = cmd.getMemberId();
                    String password;
                    if(cmd.getPassword() != null){
                        password = cmd.getPassword();
                    } else {
                        password = "";
                    }
                    boolean success = accountManager.validateAccount(memberId, password);
                    String response;
                    if (success == true) {
                        this.memberId = memberId;
                        response = "Login successful";
                    } else {
                        response = "Error: Invalid credentials";
                    }
                    Response res = new Response(response);
                    out.println(gson.toJson(res));
                    System.out.println("Sent response: " + response);
                } 
                
                //CREATE ACCOUNT
                else if (action.equals("CREATE_ACCOUNT")) {
                    String memberId = cmd.getMemberId();
                    String password;
                    if(cmd.getPassword() != null){
                        password = cmd.getPassword();
                    } else {
                        password = "";
                    }
                    boolean success = accountManager.createAccount(memberId, password);
                    String response;
                    if (success == true) {
                        response = "Account created successfully";
                    } else {
                        response = "Error: Member ID already exists";
                    }
                    Response res = new Response(response);
                    out.println(gson.toJson(res));
                    System.out.println("Sent response: " + response);
                } 

                //RESET PASSWORD
                else if (action.equals("RESET_PASSWORD")) {
                    String memberId = cmd.getMemberId();
                    String newPassword;
                    if (cmd.getPassword() != null) {
                        newPassword = cmd.getPassword();
                    } else {
                        newPassword = "";
                    }
                    boolean success = accountManager.resetPassword(memberId, newPassword);
                    String response;
                    if (success) {
                        response = "Password reset successfully";
                    } else {
                        response = "Error: Member ID does not exist";
                    }
                    Response res = new Response(response);
                    out.println(gson.toJson(res));
                    System.out.println("Sent response: " + response);
                }

                //LIST
                else if (action.equals("LIST")) {
                    List<Map<String, Object>> itemList = new ArrayList<>();
                    for (Item item : catalog.getItems().values()) {
                        if (item.isAvailable()) {
                            Map<String, Object> itemDetails = new HashMap<>();
                            itemDetails.put("title", item.getTitle());
                            itemDetails.put("author", item.getAuthor());
                            itemDetails.put("id", item.getId());
                            itemDetails.put("imageUrl", item.getImageUrl());
                            itemDetails.put("tags", item.getTags());
                            System.out.println("Item : " + item.getId() + " imageURL: " + item.getImageUrl());
                            itemList.add(itemDetails);
                        }
                    }
                    Response res = new Response(gson.toJson(itemList));
                    out.println(gson.toJson(res));
                    System.out.println("Sent response: " + gson.toJson(itemList));
                } 

                //BORROW
                else if (action.equals("BORROW")) {
                    try {
                        int itemId = cmd.getItemId();
                        String memberId = cmd.getMemberId();
                        this.memberId = memberId;
                        String response = catalog.borrowItem(itemId, memberId);
                        Response res = new Response(response);
                        out.println(gson.toJson(res));
                        System.out.println("Sent response: " + response);
                    } catch (NumberFormatException e) {
                        String response = "Error: Invalid item ID";
                        Response res = new Response(response);
                        out.println(gson.toJson(res));
                        System.out.println("Sent response: " + response);
                    }
                } 

                //RETURN
                else if (action.equals("RETURN")) {
                    try {
                        int itemId = cmd.getItemId();
                        String memberId = cmd.getMemberId();
                        this.memberId = memberId;
                        String response = catalog.returnItem(itemId, memberId);
                        Response res = new Response(response);
                        out.println(gson.toJson(res));
                        System.out.println("Sent response: " + response);
                    } catch (NumberFormatException e) {
                        String response = "Error: Invalid item ID";
                        Response res = new Response(response);
                        out.println(gson.toJson(res));
                        System.out.println("Sent response: " + response);
                    }
                } 

                //GET CHECKED OUT
                else if (action.equals("GET_CHECKED_OUT")) {
                    if (memberId == null) {
                        Response res = new Response("Error: Please log in first");
                        out.println(gson.toJson(res));
                        continue;
                    }
                    List<Map<String, Object>> checkedOutList = new ArrayList<>();
                    for (Item item : catalog.getItems().values()) {
                        if (item.getBorrowedBy() != null && item.getBorrowedBy().equals(memberId)) {
                            Map<String, Object> itemDetails = new HashMap<>();
                            itemDetails.put("title", item.getTitle());
                            itemDetails.put("author", item.getAuthor());
                            itemDetails.put("id", item.getId());
                            itemDetails.put("imageUrl", item.getImageUrl());
                            checkedOutList.add(itemDetails);
                        }
                    }
                    Response res = new Response(gson.toJson(checkedOutList));
                    out.println(gson.toJson(res));
                } 
                //GET REVIEWS
                else if (action.equals("GET_REVIEWS")) {
                    int itemId = cmd.getItemId();
                    List<Map<String, String>> reviewsList = new ArrayList<>();
                    Document query = new Document("itemId", itemId);
                    for (Document doc : reviewsCollection.find(query)) {
                        Map<String, String> review = new HashMap<>();
                        review.put("memberId", doc.getString("memberId"));
                        review.put("reviewText", doc.getString("reviewText"));
                        reviewsList.add(review);
                    }
                    Response res = new Response(gson.toJson(reviewsList));
                    out.println(gson.toJson(res));
                }
                //SUBMIT REVIEW
                else if (action.equals("SUBMIT_REVIEW")) {
                    int itemId = cmd.getItemId();
                    String memberId = cmd.getMemberId();
                    String reviewText = cmd.getString("reviewText");
                    if (reviewText == null || reviewText.trim().isEmpty()) {
                        Response res = new Response("Error: Review text cannot be empty");
                        out.println(gson.toJson(res));
                    } else {
                        Document reviewDoc = new Document("itemId", itemId)
                            .append("memberId", memberId)
                            .append("reviewText", reviewText);
                        reviewsCollection.insertOne(reviewDoc);
                        Response res = new Response("Review submitted successfully");
                        out.println(gson.toJson(res));
                    }
                }
                else {
                    Response res = new Response("Unknown command: " + command);
                    out.println(gson.toJson(res));
                }
            }
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
                System.out.println("Client disconnected");
            } catch (IOException e) {
                System.out.println("Error closing client socket: " + e.getMessage());
            }
        }
    }
}