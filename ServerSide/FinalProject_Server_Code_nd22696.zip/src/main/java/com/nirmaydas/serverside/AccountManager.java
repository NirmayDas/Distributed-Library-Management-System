package com.nirmaydas.serverside;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class AccountManager {
    private Map<String, String> accounts;
    private MongoCollection<Document> accountsCollection;
    // private final String filePath;

    public AccountManager() {
        this.accounts = new HashMap<>();
        MongoClient mongoClient = MongoClients.create("mongodb://nirmaycosmosdb12345:ZdHFvysXfRetzpaKUESRX9uXuKCmWrdoaMoD0FF4a26VlCouvY9mDANW0CH6ejeat5vcUU759vGSACDbab8FXg==@nirmaycosmosdb12345.mongo.cosmos.azure.com:10255/?ssl=true&retrywrites=false");        
        MongoDatabase database = mongoClient.getDatabase("library");
        this.accountsCollection = database.getCollection("accounts");
        loadAccounts();
    }

    private void loadAccounts() {
        accounts.clear();
        for (Document doc : accountsCollection.find()) {
            String memberId = doc.getString("memberId");
            String encryptedPassword = doc.getString("password");
            String password = PasswordEncryptor.decrypt(encryptedPassword);
            accounts.put(memberId, password);
        }
    }

    public void saveAccounts() {
        accountsCollection.drop();
        for (Map.Entry<String, String> entry : accounts.entrySet()) {
            String encryptedPassword = PasswordEncryptor.encrypt(entry.getValue());
            Document doc = new Document("memberId", entry.getKey())
                .append("password", encryptedPassword);
            accountsCollection.insertOne(doc);
        }
    }

    public boolean createAccount(String memberId, String password) {
        if (accounts.containsKey(memberId)) {
            return false;
        }
        accounts.put(memberId, password);
        saveAccounts();
        return true;
    }

    public boolean validateAccount(String memberId, String password) {
        String storedPassword = accounts.get(memberId);
        if (storedPassword == null) {
            return false;
        }
        return storedPassword.equals(password);
    }

    public boolean resetPassword(String memberId, String newPassword) {
        if (!accounts.containsKey(memberId)) {
            return false;
        }
        accounts.put(memberId, newPassword);
        saveAccounts();
        return true;
    }
}