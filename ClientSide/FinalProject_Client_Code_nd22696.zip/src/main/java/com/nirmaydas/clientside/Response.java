package com.nirmaydas.clientside; 

public class Response {
    private String response;

    public Response(String response) {
        this.response = response;
    }

    public String getResponse() {
        return response;
    }
}